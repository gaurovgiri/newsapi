from django.apps import AppConfig


class NewsapiConfig(AppConfig):
    name = 'newsapi'
