from rest_framework import serializers
from .models import news
import django.contrib.auth.models


class newsSerializer(serializers.ModelSerializer):
    class Meta:
        model = news
        fields = ['title', 'summary', 'source', 'lang', 'source_url', 'image_url']
