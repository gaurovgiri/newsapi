from django.db import models

class news(models.Model):
    title = models.TextField()
    summary = models.TextField()
    source = models.CharField(max_length=100)
    lang = models.CharField(max_length=3)
    source_url = models.TextField()
    image_url = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.title


