from django.shortcuts import render
import requests
from bs4 import BeautifulSoup
import json
import re
from .models import news
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .serializers import newsSerializer
from django.shortcuts import redirect

# Website info:
websites = iter(['https://www.news24nepal.tv/', 'https://www.kathmandupost.com', 'https://ekantipur.com/',
                 'https://www.etajakhabar.com/', 'https://nagariknews.nagariknetwork.com/'])
head_tags = iter(['div > h2', 'article > h3', 'div.teaser > h2', 'h1.wrap-head', '#politics h1 a'])
cont_tags = iter(['div.media-body.p-3 > p', 'article > p', 'div.teaser > p', 'p.lead.pt-2', '.text > p'])
sources = iter(['News24', 'KathmanduPost', 'Ekantipur', 'EtajaKhabar', 'NagarikNews'])
langs = iter(['np', 'en', 'np', 'np', 'np'])
link_tags = iter(['div.media-body.p-3 > p.news-item-link.d-none', 'article > h3 > a', 'div.teaser > h2 > a',
                  'div.wrap.mb-4 > a', '.text > h1 > a'])
img_link_tags = iter(['.banner-image', '.pull-right .img-responsive',
                      '.listLayout img',
                      'div.wrap.mb-4 > a > img', 'article.list-group-item > div.image.default > figure > a > img'])


def news_extract(website, css_head_tag, css_summary_tag, source, lang, css_source_link_tag, css_image_link_tag):
    global dbase
    news.objects.all().delete()

    ptrn_news24 = re.compile(r'\nhttps:+')
    ptrn_nagariknews = r'(?:\n|\t| {2,})'
    try:
        for each_time in range(6):
            website_addr = next(website)
            r = requests.get(website_addr)
            soup = BeautifulSoup(r.content, 'html5lib')
            heading = soup.select(next(css_head_tag))
            heading = heading[:4]
            content = soup.select(next(css_summary_tag))
            links = soup.select(next(css_source_link_tag))
            img_links = soup.select(next(css_image_link_tag))
            img_links = img_links[:4]
            head = []
            cont = []
            link = []
            img_link = []
            lang_name = next(lang)
            source_name = next(source)
            for each_heading in heading:
                if source_name == 'NagarikNews':
                    matches = re.sub(ptrn_nagariknews, r'', each_heading.text)
                    head.append(matches)
                elif source_name == 'News24':
                    head.append(str(each_heading.text)[6:])
                else:
                    head.append(each_heading.text)
            for each_content in content:
                if re.match(ptrn_news24, each_content.text):
                    continue
                else:
                    cont.append(each_content.text)
            for each_link in links:
                if source_name == 'News24':
                    link.append(str(each_link.text)[1:])
                elif source_name == 'NagarikNews':
                    link.append('https://nagariknews.nagariknetwork.com' + each_link.get('href'))
                elif source_name == 'KathmanduPost':
                    link.append('https://kathmandupost.com' + each_link.get('href'))
                else:
                    link.append(each_link.get('href'))
            for each_img_link in img_links:
                if source_name == 'News24':
                    rem_xtra_str_front = str(each_img_link.get('style'))[15:]
                    rem_xtra_str_back = rem_xtra_str_front[:-18]
                    img_link.append(rem_xtra_str_back)
                elif source_name == 'EtajaKhabar':
                    img_link.append(each_img_link.get('src'))
                elif source_name == 'NagarikNews' or source_name == 'KathmanduPost' or source_name == 'Ekantipur':
                    img_link.append(each_img_link.get('data-src'))

            for i in range(len(head)):
                dbase = news.objects.create(title=head[i],
                                            summary=cont[i],
                                            source=source_name,
                                            lang=lang_name,
                                            source_url=link[i],
                                            image_url=img_link[i])

    except StopIteration:
        dbase.save()


class all_news(APIView):
    def get(self, request):
        news_all = news.objects.all()
        serializer = newsSerializer(news_all, many=True, allow_null=True)
        return Response(serializer.data)

    def post(self):
        pass


def news_side(req):
    news_extract(websites, head_tags, cont_tags, sources, langs, link_tags, img_link_tags)
    return redirect('/api')
