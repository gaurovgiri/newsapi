from django.contrib import admin
from .models import news

admin.site.register(news)
# Register your models here.
